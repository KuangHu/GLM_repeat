# Explainer v0.3 CPU review packet

This packet includes code, 17 semantic tests, all eight original public DNA/GenBank
records, frozen candidates before and after CDS annotation, complete v0.3 evidence,
the unchanged random10 and previous review selection, and validation references.
After installing CPU dependencies, regeneration needs no repository checkout,
genome downloads, torch, model weights, GPU, or detector recalibration.
Start with FIXES_zh.txt or EXPLAINER_V3.md. The latter describes the original
repository layout; use the packet-relative commands below for this archive.

## Rebuild and compare everything

Extract into a fresh directory, cd into it, create a Python 3.10+ environment:

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r environment/requirements-tested.txt
python scripts/verify_explainer_packet.py --run-tests --rerun rerun
```

requirements-review.txt gives the supported dependency ranges; requirements-tested
records the exact CPU dependency versions used to build and verify this release.
Installing packages can require network access; the verification and rebuild do not.
`python scripts/verify_explainer_packet.py` checks the manifest, sequence inventory,
FASTA/GenBank identity and candidate bounds without regeneration.

The one-command rebuild regenerates CDS context from candidates_pre_cds and the
archived GenBank, then controls, all 467 heldout candidates, engineering validation,
and the review set. It compares every scientific TSV column in row order against
outputs/, along with summaries and original review DNA, and writes
rerun/reproduction.json. Decimal cells allow relative/absolute tolerance 1e-12;
counts, coordinates, DNA, labels and IDs must match exactly. The descriptive
CDS_annotation_source path is the only ignored annotation-table column. Relocated
path-keyed provenance JSONs, source-code byte hashes and historical package-check
metadata are not scientific output comparisons; fresh provenance is still emitted.
The script never rewrites outputs/, code or source data. Reuse a new/empty rerun
directory for each experiment.

Expected result: controls 15 candidates / 92 hypotheses / 1526 copy-evidence rows;
heldout 467 candidates / 1641 hypotheses / 9313 rows; candidate states
259 associated, 84 flank-only, 124 unresolved; 5991 extension attempts, 147 rejected
attempts retaining their cores; review set 48 candidates and 219 navigation groups.
These are engineering/evidence counts, not validated biological systems.

## Individual stages (use a separate new directory)

```bash
python scripts/explain_repeats_v3.py --candidates outputs/inputs/controls.tsv --genomes data/genomes.fa --out rerun/controls
python scripts/explain_repeats_v3.py --candidates outputs/inputs/heldout.tsv --genomes data/genomes.fa --out rerun/heldout_primary
python scripts/validate_explainer_v3.py --controls rerun/controls --heldout rerun/heldout_primary --genomes data/genomes.fa --control-definitions data/controls_definition.tsv --annotated-units data/annotated_units.tsv --v2-heldout data/v2_heldout --out rerun/validation
python scripts/make_review_set_v3.py --results rerun/heldout_primary --genomes data/genomes.fa --previous-review data/previous_review.tsv --fixed-random data/fixed_random.tsv --out rerun/review_set
```

MANIFEST.sha256 covers exact archived bytes, with no LF/CRLF normalization, and
excludes machine caches and the manifest itself. The archive intentionally retains
the frozen files' original line endings. Extracting the ZIP preserves these bytes;
opening/resaving a file with newline conversion can invalidate its checksum.
Existing frozen provenance retains historical source paths; data/SOURCES.json
documents accession versions, sequence lengths and sequence hashes of this snapshot.
Candidate association and annotation overlap do not establish biological function.
Alternative hypotheses share physical sequence; do not count evidence rows as
independent repeat copies. No independent natural VIPR validation is supplied.
